JT Contractor System - Install Perfect Version

Best install experience:
1. Unzip the folder.
2. Host the folder on any HTTPS service for true PWA install, or open in Chrome/Safari and use Add to Home Screen.
3. Android Chrome:
   - Open app
   - If Install Now banner appears, tap it
   - Otherwise use browser menu > Add to Home screen
4. iPhone Safari:
   - Open app
   - Share > Add to Home Screen

Improvements in this version:
- stronger PWA manifest
- Apple touch icon support
- in-app install banner
- clearer install instructions
- better standalone app behavior metadata
